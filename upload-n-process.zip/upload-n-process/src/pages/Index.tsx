import React, { useState, useEffect, useCallback } from 'react';
import Header from '@/components/Header';
import ParallaxSection from '@/components/ParallaxSection';
import VideoUploader from '@/components/VideoUploader';
import VideoProcessor from '@/components/VideoProcessor';
import VideoStatus from '@/components/VideoStatus';
import { VideoFile } from '@/services/api';
import { motion } from 'framer-motion';
import { useToast } from "@/hooks/use-toast";

const Index: React.FC = () => {
  const [videos, setVideos] = useState<VideoFile[]>([]);
  const [processingIds, setProcessingIds] = useState<string[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    const loadSavedData = () => {
      try {
        const savedVideos = localStorage.getItem('uploadedVideos');
        if (savedVideos) {
          const parsedVideos = JSON.parse(savedVideos);
          const validVideos = parsedVideos.map((video: any) => ({
            file_id: video.file_id,
            status: video.status || 'Pending',
            thumbnailUrl: video.thumbnailUrl,
            createdAt: new Date(video.createdAt),
            name: video.name,
            progress: video.progress || 0,
            fps: video.fps || 0
          }));
          setVideos(validVideos);
        }
        
        const savedProcessingIds = localStorage.getItem('processingIds');
        if (savedProcessingIds) {
          setProcessingIds(JSON.parse(savedProcessingIds));
        }
      } catch (error) {
        console.error('Error loading saved data:', error);
        toast({
          title: "Error",
          description: "Failed to load saved data",
          variant: "destructive"
        });
      }
    };

    loadSavedData();
  }, [toast]);

  const handleVideoUploaded = useCallback((videoFile: VideoFile) => {
    const newVideo = {
      file_id: videoFile.file_id,
      status: videoFile.status || 'Pending',
      thumbnailUrl: videoFile.thumbnailUrl,
      createdAt: videoFile.createdAt,
      name: videoFile.name,
      progress: videoFile.progress || 0,
      fps: videoFile.fps || 0
    };
    setVideos(prev => [...prev, newVideo]);
    toast({
      title: "Success",
      description: "Video uploaded successfully",
    });
  }, [toast]);

  const handleVideoDeleted = useCallback((fileId: string) => {
    setVideos(prev => prev.filter(video => video.file_id !== fileId));
    setProcessingIds(prev => prev.filter(id => id !== fileId));
  }, []);

  const handleProcessStarted = useCallback((videoId: string) => {
    setProcessingIds(prev => [...prev, videoId]);
  }, []);

  useEffect(() => {
    localStorage.setItem('uploadedVideos', JSON.stringify(videos));
  }, [videos]);

  useEffect(() => {
    localStorage.setItem('processingIds', JSON.stringify(processingIds));
  }, [processingIds]);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Header />
      
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-background z-10" />
          <motion.div 
            className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-50 via-background to-background"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.5 }}
          />
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <motion.div 
            className="max-w-3xl mx-auto text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            <motion.div
              className="inline-block mb-10"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              <img 
                src="/lovable-uploads/21dd4bd9-4dc0-461a-b51b-88ace5f99227.png" 
                alt="ACL Digital" 
                className="h-16 md:h-20 mx-auto"
              />
            </motion.div>
            
            <motion.h1 
              className="text-5xl md:text-6xl lg:text-7xl font-medium mb-6 text-primary"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.5 }}
            >
              Auto Annotation
            </motion.h1>
            
            <motion.p 
              className="text-xl md:text-2xl text-foreground/70 mb-10"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.6 }}
            >
              Automated video processing and object detection with AI
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.7 }}
            >
              <a 
                href="#upload" 
                className="px-8 py-3 rounded-lg bg-primary text-white hover:bg-primary/90 
                  focus:ring-4 focus:ring-primary/20 button-hover inline-block"
              >
                Get Started
              </a>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Upload Section */}
      <ParallaxSection
        id="upload"
        title="Upload Your Video"
        subtitle="Drag and drop your video file or browse to select"
        bgColor="bg-background"
        index={1}
      >
        <VideoUploader 
          onVideoUploaded={handleVideoUploaded}
          videos={videos}
          onVideoDeleted={handleVideoDeleted}
        />
      </ParallaxSection>
      
      {/* Process Section */}
      <ParallaxSection
        id="process"
        title="Process Your Video"
        subtitle="Select a video to apply auto annotation"
        bgColor="bg-blue-50"
        index={2}
      >
        {videos.length > 0 ? (
          <div className="space-y-6">
            <VideoProcessor 
              videos={videos}
              onProcessStarted={handleProcessStarted}
            />
          </div>
        ) : (
          <div className="text-center py-12 glass rounded-xl">
            <p className="text-foreground/70">
              No videos available. Please upload a video first.
            </p>
          </div>
        )}
      </ParallaxSection>
      
      {/* Status Section */}
      <ParallaxSection
        id="status"
        title="Processing Status"
        subtitle="Track progress and download processed videos"
        bgColor="bg-background"
        index={3}
      >
        <VideoStatus 
          videos={videos}
          processingIds={processingIds}
          onVideoDeleted={handleVideoDeleted}
        />
      </ParallaxSection>
      
      {/* Footer */}
      <footer className="py-12 bg-blue-50 border-t border-border">
        <div className="container mx-auto px-4 text-center">
          <img 
            src="/lovable-uploads/21dd4bd9-4dc0-461a-b51b-88ace5f99227.png" 
            alt="ACL Digital" 
            className="h-10 mx-auto mb-4"
          />
          <p className="text-foreground/60">
            © {new Date().getFullYear()} ACL Digital. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
