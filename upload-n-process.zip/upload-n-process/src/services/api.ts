const API_BASE_URL = "http://localhost:8001/auto_annotation";

// Types
export interface VideoFile {
  file_id: string;
  status: string;
  thumbnailUrl?: string;
  createdAt: Date;
  name: string;
  progress?: number;
  fps?: number;
  total_frames?: number;
}

interface SegmentationPoint {
  x: number;
  y: number;
  label?: number;
}

interface SamData {
  points: SegmentationPoint[];
  box?: {
    x1: number;
    y1: number;
    x2: number;
    y2: number;
  };
  model: string;
}

// WebSocket connection
let ws: WebSocket | null = null;
let messageQueue: any[] = [];
let messageListeners: ((data: any) => void)[] = [];
let isConnecting = false;
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 3;
let isConnectionClosed = false;

const connectWebSocket = () => {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }

  isConnecting = true;
  isConnectionClosed = false;
  ws = new WebSocket(`ws://localhost:8001/auto_annotation/ws`);

  ws.onopen = () => {
    console.log('WebSocket connected');
    isConnecting = false;
    reconnectAttempts = 0;
    isConnectionClosed = false;
    // Process any queued messages
    while (messageQueue.length > 0) {
      const message = messageQueue.shift();
      if (ws?.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(message));
      }
    }
  };

  ws.onclose = () => {
    console.log('WebSocket disconnected');
    isConnecting = false;
    isConnectionClosed = true;
    if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
      reconnectAttempts++;
      console.log(`Attempting to reconnect (${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS})...`);
      setTimeout(connectWebSocket, 1000 * reconnectAttempts);
    }
  };

  ws.onerror = (error) => {
    console.error('WebSocket error:', error);
    isConnecting = false;
    isConnectionClosed = true;
  };

  ws.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      console.log('Received WebSocket message:', data);
      messageListeners.forEach(listener => listener(data));
    } catch (error) {
      console.error('Error parsing WebSocket message:', error);
    }
  };
};

const sendWebSocketMessage = (message: any) => {
  if (isConnectionClosed) {
    console.warn('Cannot send message: WebSocket connection is closed');
    return;
  }

  if (!ws || ws.readyState !== WebSocket.OPEN) {
    if (!isConnecting) {
      connectWebSocket();
    }
    messageQueue.push(message);
    return;
  }

  try {
    console.log('Sending WebSocket message:', message);
    ws.send(JSON.stringify(message));
  } catch (error) {
    console.error('Error sending WebSocket message:', error);
    if (!isConnecting) {
      connectWebSocket();
    }
    messageQueue.push(message);
  }
};

export const onMessage = (listener: (data: any) => void) => {
  messageListeners.push(listener);
  if (!ws || ws.readyState !== WebSocket.OPEN) {
    connectWebSocket();
  }
  return () => {
    messageListeners = messageListeners.filter(l => l !== listener);
  };
};

// API Endpoints
const API = {
  // Upload a video file
  uploadVideo: async (file: File): Promise<{ file_id: string; message: string; fps: number }> => {
    if (!ws) connectWebSocket();

    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64Data = reader.result as string;
        const fileData = base64Data.split(',')[1]; // Remove the data:video/mp4;base64, prefix

        const message = {
          action: "upload",
          file_data: fileData
        };

        sendWebSocketMessage(message);

        const listener = (data: any) => {
          if (data.action === "upload" && data.file_id) {
            resolve({
              file_id: data.file_id,
              message: data.message,
              fps: data.fps
            });
            messageListeners = messageListeners.filter(l => l !== listener);
          } else if (data.action === "error") {
            reject(new Error(data.message));
            messageListeners = messageListeners.filter(l => l !== listener);
          }
        };
        onMessage(listener);
      };
      reader.onerror = () => reject(new Error("Failed to read file"));
      reader.readAsDataURL(file);
    });
  },

  // Process a video
  processVideo: async (
    file_id: string,
    classes: string,
    desired_fps: number,
    toggle_flag: boolean,
    confidence_threshold: number
  ): Promise<{ file_id: string; message: string; input_classes: string[]; file_data?: string }> => {
    if (!ws) connectWebSocket();

    const message = {
      action: "process",
      file_id,
      classes,
      desired_fps,
      toggle: toggle_flag,
      confidence_threshold
    };

    sendWebSocketMessage(message);

    return new Promise((resolve, reject) => {
      const listener = (data: any) => {
        if (data.action === "process" && data.file_id === file_id) {
          resolve(data);
          messageListeners = messageListeners.filter(l => l !== listener);
        } else if (data.action === "error" && data.file_id === file_id) {
          reject(new Error(data.message));
          messageListeners = messageListeners.filter(l => l !== listener);
        }
      };
      onMessage(listener);
    });
  },

  // Interrupt processing
  interruptProcessing: async (
    file_id: string,
    frame_num: number,
    stopType: "STOPPROCESS" | "STOPDETECTION" | null = null,
    iou?: number
  ): Promise<{ file_id: string; message: string; frame_num: number; status: string }> => {
    if (!ws) connectWebSocket();

    const message = {
      action: "interrupt",
      file_id,
      frame_num,
      STOP: stopType,
      IOU: iou
    };

    sendWebSocketMessage(message);

    return new Promise((resolve, reject) => {
      const listener = (data: any) => {
        if (data.action === "interrupt" && data.file_id === file_id) {
          resolve(data);
          messageListeners = messageListeners.filter(l => l !== listener);
        } else if (data.action === "error" && data.file_id === file_id) {
          reject(new Error(data.message));
          messageListeners = messageListeners.filter(l => l !== listener);
        }
      };
      onMessage(listener);
    });
  },

  // Check processing status
  checkStatus: async (file_id: string): Promise<{ file_id: string; status: string; progress?: number }> => {
    if (!ws) connectWebSocket();

    const message = {
      action: "status",
      file_id
    };

    sendWebSocketMessage(message);

    return new Promise((resolve, reject) => {
      const listener = (data: any) => {
        if (data.action === "status" && data.file_id === file_id) {
          resolve(data);
          messageListeners = messageListeners.filter(l => l !== listener);
        } else if (data.action === "error" && data.file_id === file_id) {
          reject(new Error(data.message));
          messageListeners = messageListeners.filter(l => l !== listener);
        }
      };
      onMessage(listener);
    });
  },

  // Start frame streaming
  startStreaming: (file_id: string, display_mode: string = "labels") => {
    if (!ws) connectWebSocket();
    console.log('Starting frame streaming for file:', file_id, 'with display mode:', display_mode);
    sendWebSocketMessage({ 
      action: "start_streaming", 
      file_id,
      display_mode
    });
  },

  // Pause streaming
  pauseStreaming: () => {
    if (!ws) connectWebSocket();
    console.log('Pausing frame streaming');
    sendWebSocketMessage({ action: "PAUSE" });
  },

  // Resume streaming
  resumeStreaming: (bBox: any, file_id: string, display_mode: string = "labels") => {
    if (!ws) connectWebSocket();
    console.log('Resuming frame streaming for file:', file_id, 'with display mode:', display_mode);
    sendWebSocketMessage({ 
      action: "RESUME", 
      bBox,
      file_id,
      display_mode
    });
  },

  // Download video URL
  getDownloadUrl: (file_id: string): string => {
    return `${API_BASE_URL}/download/${file_id}`;
  },

  // Download the processed video file
  downloadVideo: async (file_id: string): Promise<void> => {
    if (!ws) connectWebSocket();

    return new Promise((resolve, reject) => {
      const message = {
        action: "download",
        file_id
      };

      sendWebSocketMessage(message);

      const listener = (data: any) => {
        if (data.action === "download" && data.file_id === file_id) {
          try {
            // Convert base64 to blob
            const byteCharacters = atob(data.file_data);
            const byteNumbers = new Array(byteCharacters.length);
            for (let i = 0; i < byteCharacters.length; i++) {
              byteNumbers[i] = byteCharacters.charCodeAt(i);
            }
            const byteArray = new Uint8Array(byteNumbers);
            const blob = new Blob([byteArray], { type: "video/mp4" });

            // Create download link
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.download = `${file_id}_processed.mp4`;
            document.body.appendChild(link);
            link.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(link);

            resolve();
          } catch (error) {
            console.error("Error processing downloaded file:", error);
            reject(error);
          }
          messageListeners = messageListeners.filter(l => l !== listener);
        } else if (data.action === "error" && data.file_id === file_id) {
          reject(new Error(data.message));
          messageListeners = messageListeners.filter(l => l !== listener);
        }
      };
      onMessage(listener);
    });
  },

  // Download segmented annotated images (zip)
  downloadannotatedImages: async (file_id: string): Promise<void> => {
    try {
      const response = await fetch(`${API_BASE_URL}/download/images/${file_id}`, {
        method: "GET",
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to download annotated images");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${file_id}_annotated_frames.zip`;
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);
    } catch (error) {
      console.error("Error downloading annotated images:", error);
      throw error;
    }
  },

  // Update segmentation points with SAM
  updateSegmentationPoints: async (file_id: string, samData: SamData): Promise<void> => {
    if (!ws) connectWebSocket();

    return new Promise((resolve, reject) => {
      const message = {
        action: "update_points",
        file_id,
        points: samData.points,
        box: samData.box,
        model: samData.model
      };

      sendWebSocketMessage(message);

      const listener = (data: any) => {
        if (data.action === "update_points" && data.file_id === file_id) {
          if (data.status === "success") {
            resolve();
          } else {
            reject(new Error(data.message || "Failed to update points"));
          }
          messageListeners = messageListeners.filter(l => l !== listener);
        } else if (data.action === "error" && data.file_id === file_id) {
          reject(new Error(data.message));
          messageListeners = messageListeners.filter(l => l !== listener);
        }
      };
      onMessage(listener);
    });
  },
};

export default API;

