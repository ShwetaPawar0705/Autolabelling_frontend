
import React from 'react';
import { motion } from 'framer-motion';

const Header: React.FC = () => {
  return (
    <motion.header 
      className="fixed top-0 left-0 right-0 z-50 glass px-6 py-4 flex items-center justify-between"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <motion.div 
        className="flex items-center gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.6 }}
      >
        <img 
          src="/lovable-uploads/21dd4bd9-4dc0-461a-b51b-88ace5f99227.png" 
          alt="ACL Digital" 
          className="h-8 md:h-10"
        />
        <div className="text-xl font-medium text-primary ml-2">Auto Annotation</div>
      </motion.div>
      
      <nav>
        <ul className="flex space-x-8">
          {['Upload', 'Process', 'Status'].map((item, index) => (
            <motion.li 
              key={item}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 + index * 0.1, duration: 0.6 }}
            >
              <a 
                href={`#${item.toLowerCase()}`}
                className="text-foreground/80 hover:text-primary relative group"
              >
                {item}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary transition-all duration-300 group-hover:w-full"></span>
              </a>
            </motion.li>
          ))}
        </ul>
      </nav>
    </motion.header>
  );
};

export default Header;
