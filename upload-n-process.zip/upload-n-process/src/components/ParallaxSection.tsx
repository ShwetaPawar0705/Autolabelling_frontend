
import React, { useEffect, useRef, ReactNode } from 'react';
import { motion } from 'framer-motion';

interface ParallaxSectionProps {
  id: string;
  title: string;
  subtitle?: string;
  bgColor?: string;
  children: ReactNode;
  parallaxFactor?: number;
  index: number;
}

const ParallaxSection: React.FC<ParallaxSectionProps> = ({
  id,
  title,
  subtitle,
  bgColor = 'bg-background',
  children,
  parallaxFactor = 0.2,
  index
}) => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const handleScroll = () => {
      if (!sectionRef.current || !contentRef.current) return;
      
      const sectionTop = sectionRef.current.offsetTop;
      const scrollPosition = window.scrollY;
      const windowHeight = window.innerHeight;
      
      // Calculate how far the section is from the viewport center
      const distanceFromCenter = sectionTop - scrollPosition - windowHeight / 2;
      
      // Apply parallax effect
      const translateY = distanceFromCenter * parallaxFactor;
      contentRef.current.style.transform = `translateY(${translateY}px)`;
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [parallaxFactor]);
  
  return (
    <section
      id={id}
      ref={sectionRef}
      className={`min-h-screen ${bgColor} relative overflow-hidden flex items-center justify-center`}
    >
      <div ref={contentRef} className="container mx-auto px-4 py-24 md:py-32 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          viewport={{ once: true, margin: "-100px" }}
          className="max-w-4xl mx-auto mb-16 text-center"
        >
          <div className="inline-block mb-3">
            <div className="px-3 py-1 text-xs font-medium text-primary bg-primary/10 rounded-full">
              Section {index}
            </div>
          </div>
          <h2 className="text-4xl md:text-5xl font-medium mb-6">{title}</h2>
          {subtitle && (
            <p className="text-lg md:text-xl text-foreground/70">{subtitle}</p>
          )}
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          viewport={{ once: true, margin: "-100px" }}
        >
          {children}
        </motion.div>
      </div>
    </section>
  );
};

export default ParallaxSection;
