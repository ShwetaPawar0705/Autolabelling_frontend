import React, { useState, useEffect, useCallback } from 'react';
import { useToast } from "@/hooks/use-toast";
import { VideoFile, onMessage } from '@/services/api';
import API from '@/services/api';
import { motion } from 'framer-motion';
import { Play, StopCircle, PauseCircle, AlertCircle } from 'lucide-react';
import { Button } from "@/components/ui/button";

interface VideoProcessorProps {
  videos: VideoFile[];
  onProcessStarted: (videoId: string) => void;
}

interface WebSocketMessage {
  file_id: string;
  action: string;
  type?: string;
  frame?: string;
  frameIndex?: number;
  annotations?: boolean;
  message?: string;
  status?: string;
  progress?: number;
}

const VideoProcessor: React.FC<VideoProcessorProps> = ({ videos, onProcessStarted }): JSX.Element => {
  const { toast } = useToast();
  const [selectedVideo, setSelectedVideo] = useState<VideoFile | null>(null);
  const [classInput, setClassInput] = useState<string>('person, car, traffic_light');
  const [desiredFps, setDesiredFps] = useState<number>(30);
  const [toggleFlag, setToggleFlag] = useState<boolean>(false);
  const [currentlyProcessing, setCurrentlyProcessing] = useState<string | null>(null);
  const [processingStatus, setProcessingStatus] = useState<string>('');
  const [currentFrame, setCurrentFrame] = useState<number>(0);
  const [currentFrameData, setCurrentFrameData] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [confidenceThreshold, setConfidenceThreshold] = useState<number>(0.5);
  const [displayMode, setDisplayMode] = useState<'labels' | 'mask'>('labels');

  const handleVideoSelect = useCallback((video: VideoFile) => {
    setSelectedVideo(video);
    setCurrentFrame(0);
    setProcessingStatus('');
  }, []);

  const handleWebSocketMessage = useCallback((data: WebSocketMessage) => {
    if (data.file_id === selectedVideo?.file_id) {
      console.log('Received WebSocket message:', data);
      
      if (data.action === "frame") {
        try {
          console.log('Frame data received:', data.frame);
          
          if (Object.keys(data).includes('frame_data')) {
            let frameData = data['frame_data'];
            if (!frameData.startsWith('data:image/jpeg;base64,')) {
              frameData = `data:image/jpeg;base64,${frameData}`;
            }
            console.log(frameData);
            setCurrentFrameData(frameData);
            setCurrentFrame(data.frameIndex || 0);
            
            console.log(`Processed frame ${data.frameIndex}`);
          }
        } catch (error) {
          console.error('Error processing frame data:', error);
        }
      } else if (data.action === "progress") {
        setProcessingStatus(`Processing ${data.progress}%`);
      } else if (data.action === "completed") {
        setProcessingStatus("Completed");
        setCurrentlyProcessing(null);
        setCurrentFrameData(null);
        toast({ title: "Processing complete", description: "Video processing has been completed" });
      } else if (data.action === "error") {
        setProcessingStatus("Failed");
        setCurrentlyProcessing(null);
        setCurrentFrameData(null);
        toast({ 
          title: "Error", 
          description: data.message || "An error occurred during processing",
          variant: "destructive"
        });
      } else if (data.action === "interrupt" && data.status) {
        if (data.status === "STOPPROCESS") {
          setCurrentlyProcessing(null);
          setProcessingStatus('Stopped');
          setCurrentFrameData(null);
          toast({ title: "Process stopped", description: "Video processing has been completely stopped" });
        } else if (data.status === "STOPDETECTION") {
          setProcessingStatus('Detection Stopped');
          toast({ title: "Detection stopped", description: "Object detection has been stopped, processing continues" });
        } else {
          setProcessingStatus('Interrupted');
          setCurrentFrameData(null);
          toast({ title: "Process interrupted", description: "Video processing has been interrupted" });
        }
      }
    }
  }, [selectedVideo, toast]);

  useEffect(() => {
    const removeListener = onMessage((data) => {
      handleWebSocketMessage(data);
    });

    return () => {
      removeListener();
      if (currentlyProcessing) {
        API.interruptProcessing(currentlyProcessing, 0, "STOPPROCESS").catch(console.error);
      }
      setCurrentFrameData(null);
      setProcessingStatus('');
    };
  }, [handleWebSocketMessage, currentlyProcessing]);
  console.log(currentlyProcessing);

  useEffect(() => {
    if (selectedVideo) {
      setCurrentFrame(0);
      setCurrentFrameData(null);
      setProcessingStatus('P');
      
      if (currentlyProcessing && currentlyProcessing !== selectedVideo.file_id) {
        API.interruptProcessing(currentlyProcessing, 0, "STOPPROCESS").catch(console.error);
      }
    }
  }, [selectedVideo, currentlyProcessing]);

  const handleStartProcessing = async () => {
    if (!selectedVideo) {
      toast({ title: "No video selected", description: "Please select a video to process", variant: "destructive" });
      return;
    }

    if (!classInput.trim()) {
      toast({ title: "Missing classes", description: "Please enter at least one class for detection", variant: "destructive" });
      return;
    }

    setIsLoading(true);
    setProcessingStatus('Processing...');
    setCurrentFrame(0);
    setCurrentFrameData(null);

    try {
      const result = await API.processVideo(
        selectedVideo.file_id, 
        classInput, 
        desiredFps, 
        toggleFlag,
        confidenceThreshold
      );

      if (result && result.input_classes) {
        await API.startStreaming(selectedVideo.file_id, displayMode);
        
        setCurrentlyProcessing(selectedVideo.file_id);
        onProcessStarted(selectedVideo.file_id);
        setProcessingStatus('Processing');
        toast({ 
          title: "Processing started", 
          description: `Processing with ${desiredFps} FPS, confidence threshold ${confidenceThreshold}, and classes: ${result.input_classes.join(', ')}` 
        });
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to start processing";
      toast({ title: "Processing failed", description: errorMessage, variant: "destructive" });
      setProcessingStatus('Failed');
      setCurrentlyProcessing(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStopProcess = async () => {
    if (!selectedVideo) return;
    
    try {
      setIsLoading(true);
      setCurrentFrame(0);
      setProcessingStatus('Stopping...');
      
      const response = await API.interruptProcessing(selectedVideo.file_id, 0, "STOPPROCESS");
      if (response.status === "STOPPROCESS") {
        toast({
          title: "Processing stopped",
          description: "Video processing has been stopped",
        });
        setCurrentlyProcessing(null);
        setProcessingStatus('Stopped');
      } else {
        throw new Error("Failed to stop processing");
      }
    } catch (error) {
      console.error("Error stopping process:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to stop processing",
        variant: "destructive",
      });
      setProcessingStatus('Failed');
      setCurrentlyProcessing(null);
      setCurrentFrame(0);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStopDetection = async () => {
    if (!selectedVideo) return;
    
    try {
      const response = await API.interruptProcessing(selectedVideo.file_id, 0, "STOPDETECTION");
      if (response.status === "STOPDETECTION") {
        toast({
          title: "Detection stopped",
          description: "Object detection has been stopped, processing continues",
        });
        setProcessingStatus('Detection Stopped');
      } else {
        throw new Error("Failed to stop detection");
      }
    } catch (error) {
      console.error("Error stopping detection:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to stop detection",
        variant: "destructive",
      });
      setProcessingStatus('Failed');
      setCurrentlyProcessing(null);
      setCurrentFrame(0);
    }
  };

  const handleInterrupt = async (interruptType: 'stop' | 'detection' | 'default') => {
    if (!currentlyProcessing) {
      toast({ title: "No active process", description: "There is no video being processed", variant: "destructive" });
      return;
    }

    setIsLoading(true);
    setProcessingStatus(interruptType === 'stop' ? 'Stopping...' : interruptType === 'detection' ? 'Stopping detection...' : 'Stopping...');

    try {
      let result;
      if (interruptType === 'stop') {
        result = await API.interruptProcessing(currentlyProcessing, 0, "STOPPROCESS");
        setCurrentlyProcessing(null);
        setProcessingStatus('Stopped');
        setCurrentFrame(0);
        setCurrentFrameData(null);
        toast({ title: "Process stopped", description: "Video processing has been completely stopped" });
      } else if (interruptType === 'detection') {
        result = await API.interruptProcessing(currentlyProcessing, 0, "STOPDETECTION");
        setProcessingStatus('Detection Stopped');
        toast({ title: "Detection stopped", description: "Object detection has been stopped, processing continues" });
      } else {
        result = await API.interruptProcessing(currentlyProcessing, 0, null);
        setProcessingStatus('Interrupted');
        toast({ title: "Process interrupted", description: "Processing has been interrupted" });
      }

      const statusResult = await API.checkStatus(currentlyProcessing);
      setProcessingStatus(statusResult.status);
      
    } catch (error) {
      console.error('Interrupt error:', error);
      toast({ 
        title: "Interrupt failed", 
        description: error instanceof Error ? error.message : "Failed to interrupt processing",
        variant: "destructive" 
      });
      setProcessingStatus('Failed');
      setCurrentlyProcessing(null);
      setCurrentFrame(0);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    console.log(currentFrameData);
  }, [currentFrameData]);

  return (
    <div className="max-w-6xl mx-auto">
      <h3 className="text-xl font-medium mb-4">Select Video to Process</h3>
      {videos.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {videos.map((video) => (
            <motion.div
              key={video.file_id}
              className={`video-card rounded-xl overflow-hidden border ${
                selectedVideo?.file_id === video.file_id ? 'border-primary ring-2 ring-primary/20' : 'border-border'
              }`}
              whileHover={{ y: -5 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleVideoSelect(video)}
            >
              <div className="aspect-video bg-black relative overflow-hidden">
                {video.thumbnailUrl ? (
                  <video src={video.thumbnailUrl} className="w-full h-full object-cover" muted />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-gray-100">
                    <span className="text-gray-400">No preview available</span>
                  </div>
                )}
              </div>
              <div className="p-4">
                <div className="font-medium truncate">{video.name}</div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12 glass rounded-xl">
          <p className="text-foreground/70">No uploaded videos available. Please upload a video first.</p>
        </div>
      )}

      {selectedVideo && (
        <div className="glass rounded-xl p-6 mb-6 mt-6">
          <h3 className="text-xl font-medium mb-4">Processing Configuration</h3>

          <div className="flex gap-4 mb-6 flex-wrap">
            <input
              type="text"
              value={classInput}
              onChange={(e) => setClassInput(e.target.value)}
              placeholder="Detection classes"
              className="w-full md:w-1/2 px-4 py-2 rounded-lg border"
              disabled={isLoading}
            />
            <input
              type="number"
              value={desiredFps}
              onChange={(e) => setDesiredFps(Number(e.target.value))}
              min="1"
              className="w-24 px-4 py-2 rounded-lg border"
              placeholder="FPS"
              disabled={isLoading}
            />
            <div className="flex items-center gap-2">
              <label className="text-sm">Confidence:</label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={confidenceThreshold}
                onChange={(e) => setConfidenceThreshold(Number(e.target.value))}
                className="w-32"
                disabled={isLoading}
              />
              <span className="text-sm">{confidenceThreshold.toFixed(1)}</span>
            </div>
            <div className="flex items-center gap-2">
              <label className="text-sm">Display Mode:</label>
              <select
                value={displayMode}
                onChange={(e) => setDisplayMode(e.target.value as 'labels' | 'mask')}
                className="px-4 py-2 rounded-lg border"
                disabled={isLoading}
              >
                <option value="labels">Labels</option>
                <option value="mask">Mask</option>
              </select>
            </div>
          </div>

          <div className="flex flex-wrap gap-4">
            <Button
              onClick={handleStartProcessing}
              disabled={isLoading || currentlyProcessing !== null}
              className="bg-primary hover:bg-primary/90"
            >
              Start Processing
            </Button>
            <Button
              onClick={handleStopProcess}
              disabled={!currentlyProcessing || isLoading}
              className="bg-destructive hover:bg-destructive/90"
            >
              Stop Process
            </Button>
            <Button
              onClick={handleStopDetection}
              disabled={!currentlyProcessing || isLoading}
              className="bg-orange-500 hover:bg-orange-600"
            >
              Stop Detection
            </Button>
            <Button
              onClick={() => handleInterrupt('default')}
              disabled={!currentlyProcessing || isLoading}
              className="bg-yellow-500 hover:bg-yellow-600"
            >
              Interrupt
            </Button>
          </div>

          {processingStatus && (
            <div className="mt-4 text-lg text-foreground/60">
              Status: <strong>{processingStatus}</strong>
            </div>
          )}


          {currentFrameData && (
            <div className="mt-4">
              <h3 className="text-lg font-semibold mb-2">Current Frame</h3>
              <div className="relative aspect-video rounded-lg overflow-hidden border border-gray-200">
                <img
                  src={currentFrameData}
                  alt={`Current Frame ${currentFrame + 1}`}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white text-sm p-2">
                  frame {currentFrame + 1}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default VideoProcessor;