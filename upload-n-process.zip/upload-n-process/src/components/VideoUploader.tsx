import React, { useState, useCallback, useEffect, useRef } from 'react';
import { useToast } from "@/hooks/use-toast";
import { motion } from 'framer-motion';
import { Trash, Upload, Video } from 'lucide-react';
import API, { onMessage, VideoFile } from '@/services/api';
import { Progress } from "@/components/ui/progress";

interface VideoUploaderProps {
  onVideoUploaded: (videoFile: VideoFile) => void;
  videos: VideoFile[];
  onVideoDeleted: (fileId: string) => void;
}

const VideoUploader: React.FC<VideoUploaderProps> = ({ onVideoUploaded, videos, onVideoDeleted }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [uploadedFile, setUploadedFile] = useState<VideoFile | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const removeListener = onMessage((data) => {
      if (data.action === "upload" && data.file_id) {
        const video = videos.find(v => v.file_id === data.file_id);
        if (video) {
          const updatedVideo = {
            ...video,
            fps: data.fps
          };
          onVideoUploaded(updatedVideo);
        }
      }
    });

    return () => {
      removeListener();
    };
  }, [videos, onVideoUploaded]);

  const handleDragEnter = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  }, []);

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('video/')) {
      toast({ title: "Invalid file type", description: "Please upload a video file", variant: "destructive" });
      return;
    }

    setIsUploading(true);
    setUploadProgress(0);

    try {
      const result = await API.uploadVideo(file);
      console.log('Upload result:', result);
      
      if (result && result.file_id) {
        const videoFile: VideoFile = {
          file_id: result.file_id,
          name: file.name,
          status: 'Uploaded',
          createdAt: new Date(),
          progress: 0,
          fps: result.fps
        };
        
        onVideoUploaded(videoFile);
        setUploadedFile(videoFile);
        toast({ 
          title: "Upload successful", 
          description: `Video "${file.name}" has been uploaded successfully.` 
        });
      }
    } catch (error) {
      console.error("Upload error:", error);
      const errorMessage = error instanceof Error ? error.message : "Failed to upload video";
      toast({ title: "Upload failed", description: errorMessage, variant: "destructive" });
    } finally {
      setIsUploading(false);
      setUploadProgress(100);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleFileUpload = async (file: File) => {
    if (!file.type.includes('video/')) {
      toast({
        title: "Invalid file type",
        description: "Please upload a video file",
        variant: "destructive",
      });
      return;
    }
  
    setIsUploading(true);
  
    try {
      const response = await API.uploadVideo(file);
      const videoURL = URL.createObjectURL(file);
      const videoFile: VideoFile = {
        file_id: response.file_id,
        status: "Uploaded",
        thumbnailUrl: videoURL,
        createdAt: new Date(),
        name: file.name,
        fps: response.fps
      };

      onVideoUploaded(videoFile);
      toast({
        title: "Upload successful",
        description: `Video "${file.name}" has been uploaded successfully.`,
      });
      setUploadedFile(videoFile);
    } catch (error) {
      console.error("Upload error:", error);
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload video",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleDeleteVideo = async (fileId: string) => {
    try {
      onVideoDeleted(fileId);
      toast({
        title: "Video deleted",
        description: "Video has been removed from your list.",
      });
    } catch (error) {
      console.error("Delete error:", error);
      toast({
        title: "Delete failed",
        description: "Failed to delete video",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="max-w-6xl mx-auto">
      <motion.div
        className={`border-2 border-dashed rounded-xl p-12 text-center transition-all ${
          isDragging 
            ? 'border-primary bg-primary/5' 
            : 'border-border bg-muted/50'
        }`}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.99 }}
      >
        <input
          id="file-upload"
          type="file"
          className="hidden"
          accept="video/*"
          onChange={handleFileChange}
          disabled={isUploading}
          ref={fileInputRef}
        />
        
        <div className="flex flex-col items-center justify-center">
          <div className="mb-4 w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
            <svg 
              className="w-8 h-8 text-primary" 
              fill="none" 
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={1.5} 
                d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" 
              />
            </svg>
          </div>
          
          <h3 className="text-xl font-medium mb-2">
            {isUploading ? "Uploading..." : "Upload your video"}
          </h3>
          
          <p className="text-foreground/70 mb-6">
            Drag and drop your video file here or click to browse
          </p>
          
          <label 
            htmlFor="file-upload"
            className={`px-6 py-2.5 rounded-lg text-white bg-primary hover:bg-primary/90 
              focus:ring-4 focus:ring-primary/20 button-hover
              ${isUploading ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
          >
            {isUploading ? "Uploading..." : "Select Video"}
          </label>
          
          <p className="mt-4 text-sm text-foreground/50">
            Supported formats: MP4, MOV, AVI
          </p>
        </div>
      </motion.div>

      {videos.length > 0 && (
        <div className="mt-12">
          <h3 className="text-xl font-medium mb-6">Uploaded Videos</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videos.map((video) => (
              <motion.div
                key={video.file_id}
                className="video-card rounded-xl overflow-hidden border border-border"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
              >
                <div className="aspect-video bg-black relative overflow-hidden">
                  {video.thumbnailUrl && (
                    <video
                      src={video.thumbnailUrl}
                      className="w-full h-full object-cover"
                      muted
                    />
                  )}
                </div>
                <div className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium text-lg truncate">{video.name}</h4>
                      {video.fps && (
                        <p className="text-sm text-foreground/70">
                          FPS: {video.fps}
                        </p>
                      )}
                    </div>
                    <motion.button
                      className="p-2 rounded-full hover:bg-destructive/10 text-destructive"
                      onClick={() => handleDeleteVideo(video.file_id)}
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Trash size={18} />
                    </motion.button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {isLoading && (
        <div className="mt-4">
          <div className="flex justify-between text-sm mb-1">
            <span>Uploading...</span>
            <span>{uploadProgress}%</span>
          </div>
          <Progress value={uploadProgress} className="h-2" />
        </div>
      )}

      {uploadedFile && (
        <div className="mt-4 p-4 bg-primary/5 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Video className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium">{uploadedFile.name}</span>
            </div>
            <span className="text-xs text-muted-foreground">Uploaded</span>
          </div>
          <div className="mt-2 text-xs text-muted-foreground">
            File ID: <code className="bg-primary/10 px-1.5 py-0.5 rounded">{uploadedFile.file_id}</code>
          </div>
        </div>
      )}
    </div>
  );
};

export default VideoUploader;