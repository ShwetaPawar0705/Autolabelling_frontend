document.addEventListener("DOMContentLoaded", () => {
    window.addEventListener("scroll", () => {
      let scrolled = window.scrollY;
      document.querySelector("#root").style.backgroundPosition = `center ${-scrolled * 0.5}px`;
    });
  });
  