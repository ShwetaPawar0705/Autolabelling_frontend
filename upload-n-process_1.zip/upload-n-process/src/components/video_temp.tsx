import React, { useEffect, useRef, useState } from 'react';

type BBox = {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  class: number;
};

const BoundingBoxAnnotator: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);
  const socketRef = useRef<WebSocket | null>(null);

  const [bboxes, setBboxes] = useState<BBox[]>([]);
  const [isAnnotating, setIsAnnotating] = useState(false);
  const [drawing, setDrawing] = useState(false);
  const [selectedClass, setSelectedClass] = useState(1);
  const [start, setStart] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    const socket = new WebSocket('ws://localhost:8000');
    socketRef.current = socket;

    socket.onopen = () => {
      console.log('[CLIENT] WebSocket connected');
    };

    return () => socket.close();
  }, []);

  useEffect(() => {
    const img = new Image();
    img.src = 'frame.jpg';
    img.onload = () => {
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      }
    };
    imageRef.current = img;
  }, []);

  useEffect(() => {
    const keyHandler = (e: KeyboardEvent) => {
      if (!isAnnotating) return;
      if (e.key >= '1' && e.key <= '9') {
        setSelectedClass(parseInt(e.key));
        console.log('[CLIENT] Selected Class:', parseInt(e.key));
      } else if (e.key === 'Enter') {
        console.log('[CLIENT] Annotation saved');
        socketRef.current?.send(JSON.stringify({ type: 'ANNOTATION', bboxes }));
        socketRef.current?.send(JSON.stringify({ type: 'RESUME' }));
      } else if (e.key === 'Escape') {
        console.log('[CLIENT] Annotation canceled');
        setBboxes([]);
        redrawImage();
      }
    };

    window.addEventListener('keydown', keyHandler);
    return () => window.removeEventListener('keydown', keyHandler);
  }, [isAnnotating, bboxes]);

  const redrawImage = () => {
    const canvas = canvasRef.current;
    const img = imageRef.current;
    if (canvas && img) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        drawAllBoxes(ctx);
      }
    }
  };

  const drawAllBoxes = (ctx: CanvasRenderingContext2D) => {
    ctx.strokeStyle = 'red';
    ctx.lineWidth = 2;
    bboxes.forEach((box) => {
      ctx.strokeRect(box.x1, box.y1, box.x2 - box.x1, box.y2 - box.y1);
      ctx.fillStyle = 'red';
      ctx.fillText(`Class ${box.class}`, box.x1 + 4, box.y1 + 12);
    });
  };

  const drawTempBox = (ctx: CanvasRenderingContext2D, x1: number, y1: number, x2: number, y2: number) => {
    ctx.strokeStyle = 'lime';
    ctx.lineWidth = 2;
    ctx.strokeRect(x1, y1, x2 - x1, y2 - y1);
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isAnnotating) return;
    setStart({ x: e.nativeEvent.offsetX, y: e.nativeEvent.offsetY });
    setDrawing(true);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!drawing || !isAnnotating || !start) return;
    const canvas = canvasRef.current;
    const img = imageRef.current;
    if (!canvas || !img) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const currentX = e.nativeEvent.offsetX;
    const currentY = e.nativeEvent.offsetY;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    drawAllBoxes(ctx);
    drawTempBox(ctx, start.x, start.y, currentX, currentY);
  };

  const handleMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isAnnotating || !start) return;
    const endX = e.nativeEvent.offsetX;
    const endY = e.nativeEvent.offsetY;

    const newBox: BBox = {
      x1: start.x,
      y1: start.y,
      x2: endX,
      y2: endY,
      class: selectedClass,
    };
    setBboxes((prev) => [...prev, newBox]);
    setDrawing(false);
    setStart(null);
    console.log('[CLIENT] Bounding Box Added:', newBox);
  };

  const toggleAnnotation = () => {
    setIsAnnotating((prev) => {
      const newVal = !prev;
      if (newVal) {
        socketRef.current?.send(JSON.stringify({ type: 'PAUSE' }));
        console.log('[CLIENT] Annotation mode enabled');
      } else {
        socketRef.current?.send(JSON.stringify({ type: 'RESUME' }));
        console.log('[CLIENT] Annotation mode disabled');
        redrawImage();
      }
      return newVal;
    });
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h2>Bounding Box Annotation Tool</h2>
      <button
        onClick={toggleAnnotation}
        style={{
          marginBottom: '10px',
          padding: '10px 20px',
          backgroundColor: isAnnotating ? '#28a745' : '#007bff',
          color: 'white',
          border: 'none',
          borderRadius: '5px',
          cursor: 'pointer',
        }}
      >
        {isAnnotating ? 'Stop Annotation' : 'Start Annotation'}
      </button>
      <br />
      <canvas
        ref={canvasRef}
        width={640}
        height={480}
        style={{ border: '2px solid #000', cursor: 'crosshair' }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
      />
      <div style={{ marginTop: '20px', padding: '10px', maxWidth: '640px', border: '1px solid #ddd' }}>
        <h3>Saved Annotations:</h3>
        {bboxes.map((box, index) => (
          <div key={index} style={{ background: '#f7f7f7', padding: '6px', marginBottom: '5px', borderRadius: '6px' }}>
            #{index + 1} → Class: {box.class}, Coordinates: ({box.x1}, {box.y1}) to ({box.x2}, {box.y2})
          </div>
        ))}
      </div>
    </div>
  );
};

export default BoundingBoxAnnotator;
