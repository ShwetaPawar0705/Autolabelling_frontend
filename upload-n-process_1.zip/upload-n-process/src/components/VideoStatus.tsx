import React, { useState, useEffect } from 'react';
import { useToast } from "@/hooks/use-toast";
import { VideoFile } from '@/services/api';
import API, { onMessage } from '@/services/api';
import { motion } from 'framer-motion';
import { Download, RefreshCcw, Trash } from 'lucide-react';

interface VideoStatusProps {
  videos: VideoFile[];
  processingIds: string[];
  onVideoDeleted: (fileId: string) => void;
}

const VideoStatus: React.FC<VideoStatusProps> = ({ videos, processingIds, onVideoDeleted }) => {
  const [videoStatus, setVideoStatus] = useState<Record<string, { status: string; progress: number }>>({});
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const removeListener = onMessage((data) => {
      console.log('WebSocket message received:', data);
      if (data.action === "progress" && data.file_id) {
        setVideoStatus(prev => ({
          ...prev,
          [data.file_id]: {
            status: `Processing ${data.progress}%`,
            progress: data.progress
          }
        }));
      } else if (data.action === "completed" && data.file_id) {
        setVideoStatus(prev => ({
          ...prev,
          [data.file_id]: {
            status: "Completed",
            progress: 100
          }
        }));
      } else if (data.action === "error" && data.file_id) {
        setVideoStatus(prev => ({
          ...prev,
          [data.file_id]: {
            status: "Failed",
            progress: 0
          }
        }));
        toast({ title: "Error", description: data.message, variant: "destructive" });
      } else if (data.action === "interrupt" && data.file_id) {
        const newStatus = data.status === "STOPPROCESS" ? "Stopped" : 
                         data.status === "STOPDETECTION" ? "Detection Stopped" : 
                         "Interrupted";
        
        setVideoStatus(prev => ({
          ...prev,
          [data.file_id]: {
            status: newStatus,
            progress: data.progress || prev[data.file_id]?.progress || 0
          }
        }));

        toast({ 
          title: newStatus,
          description: data.status === "STOPPROCESS" ? 
            "Video processing has been stopped" : 
            data.status === "STOPDETECTION" ? 
            "Object detection stopped, processing continues" :
            "Processing interrupted"
        });
      }
    });

    return () => {
      removeListener();
    };
  }, [toast]);

  const handleRefreshStatus = async (id: string) => {
    try {
      const result = await API.checkStatus(id);
      console.log('Status check result:', result);
      let progress = 0;
      if (result.status.includes('Processing')) {
        const match = result.status.match(/Processing (\d+)%/);
        if (match && match[1]) {
          progress = parseInt(match[1], 10);
        }
      } else if (result.status === 'Completed') {
        progress = 100;
      } else if (result.status === 'Interrupted') {
        progress = 0;
      }
      
      setVideoStatus(prev => ({
        ...prev,
        [id]: { 
          status: result.status,
          progress
        }
      }));
      
      toast({
        title: "Status refreshed",
        description: `Current status: ${result.status}`,
      });
    } catch (error) {
      console.error("Refresh error:", error);
      toast({
        title: "Refresh failed",
        description: error instanceof Error ? error.message : "Failed to refresh status",
        variant: "destructive",
      });
    }
  };

  const handleDownloadVideo = async (fileId: string) => {
    try {
      setIsDownloading(true);
      setDownloadError(null);
      await API.downloadVideo(fileId);
      toast({
        title: "Download started",
        description: "Video download has started",
      });
    } catch (error) {
      console.error('Error downloading video:', error);
      setDownloadError(error instanceof Error ? error.message : 'Failed to download video');
      toast({
        title: "Download failed",
        description: error instanceof Error ? error.message : "Failed to download video",
        variant: "destructive",
      });
    } finally {
      setIsDownloading(false);
    }
  };

  const handleDownloadAnnotated = async (fileId: string) => {
    try {
      setIsDownloading(true);
      setDownloadError(null);
      await API.downloadnnotatedImages(fileId);
      toast({
        title: "Download started",
        description: "Annotated images download has started",
      });
    } catch (error) {
      console.error('Error downloading annotated images:', error);
      setDownloadError(error instanceof Error ? error.message : 'Failed to download annotated images');
      toast({
        title: "Download failed",
        description: error instanceof Error ? error.message : "Failed to download annotated images",
        variant: "destructive",
      });
    } finally {
      setIsDownloading(false);
    }
  };

  const getStatusColor = (status: string) => {
    if (status.includes('Failed') || status.includes('Error')) return 'bg-destructive';
    if (status === 'Completed') return 'bg-green-500';
    if (status.includes('Processing')) return 'bg-primary';
    if (status === 'Interrupted') return 'bg-yellow-500';
    if (status === 'Stopped') return 'bg-gray-500';
    if (status === 'Detection Stopped') return 'bg-orange-500';
    return 'bg-secondary';
  };

  // Updated: always enabled
  const getDownloadButtonState = () => {
    return { disabled: false, tooltip: '' };
  };

  return (
    <div className="max-w-6xl mx-auto">
      <h3 className="text-xl font-medium mb-6">Processing Status</h3>
      
      {videos.length > 0 ? (
        <div className="space-y-6">
          {videos.map((video) => {
            const videoStatusData = videoStatus[video.file_id] || { status: video.status || 'Unknown', progress: 0 };
            const downloadState = getDownloadButtonState();
            
            return (
              <motion.div
                key={video.file_id}
                className="glass rounded-xl overflow-hidden border border-border"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
              >
                <div className="flex flex-col md:flex-row">
                  <div className="w-full md:w-1/3 bg-black">
                    {video.thumbnailUrl && (
                      <video
                        src={video.thumbnailUrl}
                        className="w-full h-full object-cover"
                        controls={videoStatusData.status === 'Completed'}
                        muted={videoStatusData.status !== 'Completed'}
                      />
                    )}
                  </div>
                  
                  <div className="p-6 w-full md:w-2/3">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h4 className="font-medium text-lg">{video.name}</h4>
                        <p className="text-sm text-foreground/70">
                          ID: {video.file_id}
                        </p>
                        {video.fps && (
                          <p className="text-sm text-foreground/70">
                            FPS: {video.fps}
                          </p>
                        )}
                      </div>
                      
                      <div className={`px-3 py-1 rounded-full text-xs font-medium text-white ${getStatusColor(videoStatusData.status)}`}>
                        {videoStatusData.status}
                      </div>
                    </div>
                    
                    <div className="mb-6">
                      <div className="flex justify-between text-sm mb-2">
                        <span>Progress</span>
                        <span>{videoStatusData.progress}%</span>
                      </div>
                      <div className="progress-bar">
                        <motion.div 
                          className="progress-bar-fill"
                          initial={{ width: "0%" }}
                          animate={{ width: `${videoStatusData.progress}%` }}
                          transition={{ duration: 0.5 }}
                        />
                      </div>
                    </div>
                    
                    <div className="flex justify-end space-x-3">
                      <motion.button
                        className="px-4 py-2 rounded-lg border border-destructive/30 bg-destructive/10 hover:bg-destructive/20 flex items-center gap-2 text-destructive"
                        onClick={() => onVideoDeleted(video.file_id)}
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                      >
                        <Trash size={16} />
                        <span>Delete</span>
                      </motion.button>
                      
                      <motion.button
                        className="px-4 py-2 rounded-lg border border-border bg-secondary/10 hover:bg-secondary/20 flex items-center gap-2"
                        onClick={() => handleRefreshStatus(video.file_id)}
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                      >
                        <RefreshCcw size={16} />
                        <span>Refresh</span>
                      </motion.button>

                      <motion.button
                        className={`px-4 py-2 rounded-lg border border-primary/30 bg-primary/10 flex items-center gap-2 text-primary hover:bg-primary/20`}
                        onClick={() => handleDownloadVideo(video.file_id)}
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                        title={downloadState.tooltip}
                      >
                        <Download size={16} />
                        <span>Download Video</span>
                      </motion.button>

                      <motion.button
                        className={`px-4 py-2 rounded-lg border border-primary/30 bg-primary/10 flex items-center gap-2 text-primary hover:bg-primary/20`}
                        onClick={() => handleDownloadAnnotated(video.file_id)}
                        whileHover={{ scale: 1.03 }}
                        whileTap={{ scale: 0.97 }}
                        title={downloadState.tooltip}
                      >
                        <Download size={16} />
                        <span>Download Images</span>
                      </motion.button>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-12 glass rounded-xl">
          <p className="text-foreground/70">
            No videos available. Please upload and process a video.
          </p>
        </div>
      )}
    </div>
  );
};

export default VideoStatus;
